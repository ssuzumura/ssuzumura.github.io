#include <iostream>
#include <Eigen/Core>
#include <Eigen/Cholesky>

#include "gnuplot_i.hpp"
using namespace Eigen;

int main(void)
{
  int n = 30;

  // データの作成
  VectorXd x0 = VectorXd::Ones(n); // バイアス項
  VectorXd x1 = VectorXd::LinSpaced(n, 0, 5);
  MatrixXd X(n, 2);
  X << x0, x1;
  VectorXd y = x1.array() + x1.array().sin();

  // LU分解
//  VectorXd beta = (X.transpose() * X).fullPivLu().solve(X.transpose() * y);

  // Cholesky分解
  VectorXd beta = (X.transpose() * X).ldlt().solve(X.transpose() * y);

  // 出力
  VectorXd f = X * beta;

  Gnuplot gp;
//  gp.set_GNUPlotPath("C:/gnuplot/bin/"); // Gnuplotのパスを設定（環境変数が設定済みなら不必要）
  gp.set_grid().set_style("linespoints");
  gp.plot_xy(x1, y, "x + sin(x)");
  gp.plot_xy(x1, f, "f(x)");

  std::cout << "Push enter key..." << std::endl;
  getchar();

  return 0;
}
