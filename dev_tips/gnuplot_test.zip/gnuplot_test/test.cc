#include <iostream>
#include <Eigen/Core>
#include "gnuplot_i.hpp"
using namespace Eigen;

int main(void)
{
  VectorXd x = VectorXd::LinSpaced(30, 0, 5); // 0から5までの値を30等分
  VectorXd y = x.array() + x.array().sin();

  Gnuplot gp;
//  gp.set_GNUPlotPath("C:/gnuplot/bin/"); // Gnuplotのパスを設定（環境変数が設定済みなら不必要）
  gp.set_grid().set_style("linespoints");
  gp.plot_xy(x, y, "x + sin(x)");

  std::cout << "Push enter key..." << std::endl;
  getchar();

  return 0;
}
